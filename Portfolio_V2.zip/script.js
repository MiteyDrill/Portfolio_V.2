

anime({
  targets: '#nav-list ul',
  translateX: '+= 50%',
  duration: anime.stagger(150, {start: 500}),
  easing: 'easeInQuad'
});

**Starting the project**

Execute each command in a separate terminal tab. Make sure to start up all sections you will be 
making changes to.

TODO: Look into figuring out single-command shell starts

**Client Core**  
`npm run start-core`  
This is mostly needed for TypeScript transpilation. Alternatively you can set up 
file watchers through your IDE.

**Web Client**  
`npm run start-web`

import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const Messages = () => {
    return <div data-testid="messagesPage">Messages</div>;
};

const styles = StyleSheet.create({});

export default Messages;
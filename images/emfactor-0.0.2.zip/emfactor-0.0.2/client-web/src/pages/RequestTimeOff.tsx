import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const RequestTimeOff = () => {
    return <div data-testid="requestTimeOffPage">RequestTimeOff</div>;
};

const styles = StyleSheet.create({});

export default RequestTimeOff;
import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const Notifications = () => {
    return <div data-testid="notificationsPage">Notifications</div>;
};

const styles = StyleSheet.create({});

export default Notifications;
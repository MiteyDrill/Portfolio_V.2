import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const Duties = () => {
    return <div data-testid="dutiesPage">Duties</div>;
};

const styles = StyleSheet.create({});

export default Duties;
import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const ChangeAvailability = () => {
    return <div data-testid="changeAvailabilityPage">ChangeAvailability</div>;
};

const styles = StyleSheet.create({});

export default ChangeAvailability;
import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const Policies = () => {
    return <div data-testid="policiesPage">Policies</div>;
};

const styles = StyleSheet.create({});

export default Policies;
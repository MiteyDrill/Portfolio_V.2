import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const Shifts = () => {
    return <div data-testid="manageShiftsPage">Shifts</div>;
};

const styles = StyleSheet.create({});

export default Shifts;
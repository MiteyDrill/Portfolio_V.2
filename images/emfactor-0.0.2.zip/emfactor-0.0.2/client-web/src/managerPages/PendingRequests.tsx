import React from 'react';
import {StyleSheet, css} from 'aphrodite/no-important';

const PendingRequests = () => {
    return <div data-testid="managePendingRequestsPage">PendingRequests</div>;
};

const styles = StyleSheet.create({});

export default PendingRequests;
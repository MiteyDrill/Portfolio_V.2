This folder is generally for components that are designed with reuse in mind. If you're
making a component that's probably only going to be used once (such as a page), consider putting it in
`/pages`.
**Naming Conventions**

Filenames are entityAction.ts rather than actionEntity.ts where relevant (e.g. employeeAdd.ts, not addEmployee.ts).
While this may seem counter-intuitive, it keeps relevant actions next to each other without
needing to use folders and contribute to ../../ hell.
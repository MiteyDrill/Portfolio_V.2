import login from './login';
import logout from './logout';

import addEmployee from './employeeAdd';

export {
    login,
    logout,

    addEmployee
};
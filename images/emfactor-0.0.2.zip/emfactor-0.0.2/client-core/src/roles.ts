export const ROLE_EMPLOYEE = 1;
export const ROLE_MANAGER = 2;